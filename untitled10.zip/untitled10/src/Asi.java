public class Asi {
    String isim;
    String doz;

    public Asi(String isim, String doz) {
        this.isim=isim;
        this.doz=doz;
    }
}
