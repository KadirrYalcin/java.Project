public class Kisi {
     String kullaniciAdi;
     String sifre;
    Kisi(String kullaniciAdi, String sifre){
        this.kullaniciAdi =kullaniciAdi;
        this.sifre=sifre;
    }
}
