 abstract class Authentication {
    int logIn(String kullaniciAdi,String parola){return 1;};
    void signIn(String kullaniciAdi,String parola){}
}
